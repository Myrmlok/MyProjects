﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChessServer
{
    public class ParsedJsonUser
    {
        public string RequstAndAnswer { get; set; }
        public bool CommandExecuted { get; set; }
        public string Name { get; set; }
        public string Password { get; set; }
        public int WinCount { get; set; }
        public int LoseCount { get; set; }
    }
   
}

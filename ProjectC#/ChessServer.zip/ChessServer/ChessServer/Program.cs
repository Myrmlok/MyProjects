﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
namespace ChessServer
{
    internal class Program
    {
        static TcpListener server = new TcpListener(IPAddress.Any, 8888);
        static string path = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Players;Integrated Security=True;Connect Timeout=30;";
        static List<UserClientServer> PlayersBlack=new List<UserClientServer>();
        static List<UserClientServer> PlayersWhite = new List<UserClientServer>();
        static bool IsWhite=true;
        public enum Commands
        {
            AddUser,
            Test,
            LogIn,
            Update,
            GetAllPlayers,
            GoToGame
        }
        static async Task Main(string[] args)
        {
            server.Start();
            while (true)
            {
                await Task.Yield();
                var client =await server.AcceptTcpClientAsync();
                UserClientServer user = new UserClientServer(client);
                Console.WriteLine("ClientConnected");
                _=Task.Run(() => GetCommand(user));
            }
        }
        static async Task GetCommand(UserClientServer user)
        {
       
            while (user.MyClient.Connected)
            {
                await Task.Yield();



                try
                {
  
                    
                        var read = await ReadNetworkStreamAsync(user.stream);
                        
                        var JsonParsed = JsonSerializer.Deserialize<ParsedJsonUser>(read);
                        Console.WriteLine(JsonParsed.RequstAndAnswer + " " + JsonParsed.Name);
                        switch (Convert.ToInt32(Enum.Parse(typeof(Commands), JsonParsed.RequstAndAnswer)))
                        {
                            case 0:
                                await Register(await AddPlayer(JsonParsed), JsonParsed, user);
                                break;
                            case 1:
                                Console.WriteLine("Test");
                                await SendAnswer(JsonParsed, user.stream);
                                break;
                            case 2:
                                await Register(await LogIn(JsonParsed), JsonParsed, user);
                                break;
                            case 3:
                                Console.WriteLine("Update");
                                await Register(await Update(JsonParsed, user), JsonParsed, user);
                                break;
                            case 4:
                                await JsonSerializer.SerializeAsync(user.stream, await GetAllPlayers());
                                break;
                            case 5:
                                Console.WriteLine("GoGame");
                                await StartGame(user);
                    
                                break;

                        
                    }
              
                }
                catch(Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    Console.WriteLine(user.Name);
                    user.MyClient.Close();
                    user.MyClient.Dispose();
                    user.stream.Close();
                    user.stream.Dispose();
                    
                    break;
                }
            }
        }
        static async Task StartGame(UserClientServer user)
        {
            Console.WriteLine("White " + PlayersWhite.Count + " BLack " + PlayersBlack.Count);
            UserClientServer unfriend = null;
            bool YourWhite=IsWhite;
            if (IsWhite)
            {
                IsWhite = !IsWhite;
                PlayersWhite.Add(user);
           
                while (true)
                {
                    await Task.Yield();
                    if(PlayersBlack.Count == 0) {
                        continue;
                    }
                    else
                    {
                        unfriend = PlayersBlack[0];
                        PlayersBlack.Remove(unfriend);
                        await SendAnswer(new ParsedJsonUser()
                        {
                            Name = user.Name,
                            Password = "Black",
                            LoseCount = user.LoseCount,
                            WinCount = user.WinCount
                        }, unfriend.stream);
                        break;
                    }
                }
            }
            else
            {
                IsWhite = !IsWhite;
               
                PlayersBlack.Add(user);
                unfriend = PlayersWhite[0];
                PlayersWhite.Remove(unfriend);
                await SendAnswer(new ParsedJsonUser()
                {
                    Name = user.Name,
                    Password = "White",
                    LoseCount = user.LoseCount,
                    WinCount = user.WinCount
                }, unfriend.stream);
              
            }
            
             await GameRun(user, unfriend,YourWhite);

        }
        static async Task GameRun(UserClientServer first,UserClientServer sencod,bool FirstIsWhite)
        {
            Console.WriteLine("gameRun");
            
            ParsedPlayerMove parsedPlayerMove = new ParsedPlayerMove() { Descriptioon = "Eroore" };
            while (true)
            {
                await Task.Yield();

                byte[] data = null;
                try
                {
                    data = await ReadNetworkStreamAsync(first.stream);
                    var answer = JsonSerializer.Deserialize<ParsedPlayerMove>(data);
                    Console.WriteLine(first.Name+nameof(answer.Descriptioon) + " " + answer.Descriptioon + " " + answer.x1 + ";" + answer.y1 + " " + answer.x2 + ";" + answer.y2);
                    if (answer.Descriptioon == "Break")
                    {
                        break;
                    }
                    if (answer.Descriptioon == "IsWhiteWin"|| answer.Descriptioon == "IsBlackWin")
                    {
                        try
                        {
                            await sencod.stream.WriteAsync(data, 0, data.Length);
                        }
                        catch 
                        {

                        }
                        if(answer.Descriptioon== "IsWhiteWin")
                        {
                            if (IsWhite)
                            {
                               await EndingGame(first, sencod);
                            }
                            else
                            {
                                await EndingGame(sencod, first);
                            }
                        }
                        if (answer.Descriptioon == "IsBlackWin")
                        {
                            if (IsWhite)
                            {
                                await EndingGame(sencod, first);
                            }
                            else
                            {
                                await EndingGame(first, sencod);
                            }
                        }
                        break;
                        
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    first.MyClient.Close();
                    await JsonSerializer.SerializeAsync(sencod.stream, parsedPlayerMove);
                    await EndingGame(sencod, first);
                    break;
                }
                try
                {
                    if (data != null)
                    {
                        await sencod.stream.WriteAsync(data, 0, data.Length);
                    }
                }
                catch(Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    sencod.MyClient.Close();
                    await JsonSerializer.SerializeAsync(first.stream, parsedPlayerMove);
                    await EndingGame(first, sencod);
                    break;
                }
                
              
                
            }
        }
        static async Task EndingGame(UserClientServer winner,UserClientServer loser)
        {
            using(SqlConnection sqlConnection=new SqlConnection(path))
            {
                await sqlConnection.QueryAsync($"UPDATE Players set [WinCount]='{++winner.WinCount}'  where [Name]='{winner.Name}'");
                await sqlConnection.QueryAsync($"UPDATE Players set [LoseCount]='{++loser.LoseCount}'  where [Name]='{loser.Name}'");
            }
        }
        static async Task<IEnumerable<UserDb>> GetAllPlayers()
        {
            using (SqlConnection connection = new SqlConnection(path))
            {
               return await connection.QueryAsync<UserDb>("Select [Name], [LoseCount],[WinCount] From Players ORDER BY WinCount DESC");
            }
        }
        static async Task Register( bool executed,ParsedJsonUser parsedJson,UserClientServer user)
        {
            Console.WriteLine("SendAnswer");
            parsedJson.CommandExecuted = executed;
            if (parsedJson.CommandExecuted)
            {
                user.Name = parsedJson.Name;
                user.Password = parsedJson.Password;
            }
            await SendAnswer(parsedJson, user.stream);
        } 
        static async Task<bool> AddPlayer(ParsedJsonUser user)
        {
            using (SqlConnection connection = new SqlConnection(path))
            {
                if (await connection.QueryFirstOrDefaultAsync($"Select * from Players WHERE [Name]='{user.Name}'") != null)
                {
                    return false;
                }
              
                await connection.ExecuteAsync($"INSERT INTO Players ([Name],[Password]) values('{user.Name}','{user.Password}') ");
                return true;
                
            }
        }
        static async Task<bool> Update(ParsedJsonUser user,UserClientServer userClient1)
        {
            using (SqlConnection connection = new SqlConnection(path))
            {
                if (await connection.QueryFirstOrDefaultAsync($"Select * from Players WHERE [Name]='{userClient1.Name}'") == null)
                {
                    return false;
                }
                Console.WriteLine("UpdateStart");
                await connection.ExecuteAsync($"UPDATE Players set [Name]='{user.Name}' , [Password]='{user.Password}' where [Name]='{userClient1.Name}'");
                Console.WriteLine("UpdateEnd");
                return true;
            }
        }
        static async Task<bool> LogIn(ParsedJsonUser user)
        {
            using (SqlConnection connection = new SqlConnection(path))
            {
                if( await connection.QueryFirstOrDefaultAsync($"Select * from Players WHERE [Name]='{user.Name}' and [Password]='{user.Password}'") != null)
                {
                    var res= await connection.QueryFirstOrDefaultAsync<UserDb>($"Select * from Players WHERE [Name]='{user.Name}' and [Password]='{user.Password}'");
                    user.LoseCount = res.LoseCount;
                    user.WinCount = res.WinCount;
                    return true;
                };
                return false;
            }
        }
      
        static async Task SendAnswer(ParsedJsonUser parsedJsonUser,NetworkStream stream)
        {
            parsedJsonUser.RequstAndAnswer = "IsAnswer";
            var str= JsonSerializer.Serialize(parsedJsonUser);
            Console.WriteLine(str);
            byte[] buffer = Encoding.UTF8.GetBytes(str);
            await stream.WriteAsync(buffer, 0, buffer.Length);
        }
        static async Task<byte[]> ReadNetworkStreamAsync(NetworkStream stream)
        {
            using (MemoryStream ms = new MemoryStream())
            {
                var buffer = new byte[1024];

                int count;
                do
                {
                    count = await stream.ReadAsync(buffer, 0, buffer.Length);
                     await  ms.WriteAsync(buffer, 0, count);
                    if (count < 1024)
                    {
                        return ms.ToArray();
                    }
                } while (count > 0);
                return ms.ToArray();
            }
        }
    }
}
public class UserClientServer
{
    public string Name;
    public string Password;
    public int WinCount;
    public int LoseCount;
    public TcpClient MyClient;
    public NetworkStream stream;
   
    public UserClientServer(TcpClient client)
    {
        MyClient = client;
        stream = client.GetStream();
    }
}
public class ParsedPlayerMove
{
    public int x1 { get; set; }
    public int y1 { get; set; }
    public int x2 { get; set; }
    public int y2 { get; set; }
    public string Descriptioon { get; set; }
    public string Message { get; set; }
}
public class UserDb
{
    public int Id { get; set; }
    public string Name { get; set; }
    public string Password { get; set; }
    public int WinCount { get; set; }
    public int LoseCount { get; set; }
} 

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using System.Net;
using System.IO;
namespace MyApi
{
    internal class Program
    {
        static HttpListener Api=new HttpListener();
        static async Task Main(string[] args)
        {
            Api.Prefixes.Add("http://127.0.0.1:8888/api/animal/");
            Api.Prefixes.Add("http://127.0.0.1:8888/api/plants/");
            Api.Prefixes.Add("http://127.0.0.1:8888/api/random/");
            Api.Start();
            await Task.Run(() => GetPrefix());
        }
        static async Task GetPrefix()
        {
            while (true)
            {
                await Task.Yield();
                var res = await Api.GetContextAsync();
                
                if(res.Request.RawUrl.Contains( @"/api/animal/")||res.Request.RawUrl.Contains(@"/api/plants/"))
                    await SendAnswer(res);
                if (res.Request.RawUrl.Contains(@"api/random/"))
                {
                    await GetRandomPicture(res);
                }
                res.Response.Close();
            }
                
            
        }
        static async Task SendAnswer(HttpListenerContext res)
        { 
            var RawUrl = res.Request.RawUrl;
            var index = RawUrl.LastIndexOf('/');
            var pictureName = RawUrl.Substring(index+1);
            var PictureClass = RawUrl.Substring(RawUrl.IndexOf("/api/"), index);
            if (pictureName == "GetAllName")
            {
                DirectoryInfo directoryInfo = new DirectoryInfo($@"{Directory.GetCurrentDirectory()}/{PictureClass}");
                foreach (var c in directoryInfo.EnumerateFiles())
                {
                    var data = Encoding.UTF8.GetBytes(c.Name+" ");
                    await res.Response.OutputStream.WriteAsync(data, 0, data.Length);
                };

            }
            else
            {
                try
                {
                    using (FileStream fs = new FileStream($@"{Directory.GetCurrentDirectory()}/{PictureClass}/{pictureName}", FileMode.Open, FileAccess.Read))
                    {
                        FileInfo fileInfo = new FileInfo(fs.Name);
                        byte[] data = new byte[1024];
                        int count;
                        do
                        {
                            count = await fs.ReadAsync(data, 0, data.Length);
                            await res.Response.OutputStream.WriteAsync(data, 0, count);

                            if (count < data.Length)
                            {
                                break;
                            }
                        } while (count > 0);



                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        }
        static async Task GetRandomPicture(HttpListenerContext res)
        {
            
            var RawUrl = res.Request.RawUrl;
            Console.WriteLine(RawUrl);
            var ClassName = RawUrl.Substring(RawUrl.LastIndexOf('/')+1);
            Console.WriteLine(ClassName);
            List< FileInfo> fileInfos = new List<FileInfo>();
            if (ClassName == "")
            {
                DirectoryInfo directoryInfo = new DirectoryInfo($@"{Directory.GetCurrentDirectory()}\api\");
                var FilesFromAllDirectories = directoryInfo.GetDirectories().Select(c => c.GetFiles());
                foreach(var Files in FilesFromAllDirectories)
                {
                    foreach(var e in Files)
                    {
                        fileInfos.Add(e);
                    }
                }
              
            }
            else
            {
                DirectoryInfo directoryInfo = new DirectoryInfo($@"{Directory.GetCurrentDirectory()}\api\{ClassName}");
                fileInfos=directoryInfo.GetFiles().ToList();
            }
            Random random = new Random();
            using ( FileStream fs=new FileStream( fileInfos[random.Next(0, fileInfos.Count-1)].FullName, FileMode.Open, FileAccess.Read))
            {
                byte[] data = new byte[1024];
                int count;
                do
                {
                    count = await fs.ReadAsync(data, 0, data.Length);
                    await res.Response.OutputStream.WriteAsync(data, 0, count);

                    if (count < data.Length)
                    {
                        break;
                    }
                } while (count > 0);
            } ;
        }
      
        
    }
}

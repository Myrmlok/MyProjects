﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using System.Windows;
using System.ComponentModel;
using MVMM;
using System.Windows.Controls;
using System.Runtime.CompilerServices;
namespace Chess
{
    public class ViewModal:INotifyPropertyChanged
    {
        public string musAlf = "abcdefghij";
        public Button button;
        public ObservableCollection<Players> Players { get; set; }
        public ObservableCollection<ChatMessage> chatMessages { get; set; }
        public ObservableCollection<MoveCheck> moveChecks { get; set; }
        string name="";
        public string Name
        {
            set { name = value; OnPropertyChangedvalue(); }
            get => name;
        }
        string password="";
        public string Password
        {
            set { password = value;OnPropertyChangedvalue(); }
            get => password;
        }

        string win_Lose="";
        public string Win_Lose
        {
            set { win_Lose = value;OnPropertyChangedvalue(); }
            get => win_Lose;
        }
        SideChess white;
        SideChess black;
        Figures selectedFigure;
        List<Point> canGo;
        bool whiteMove=true;
        public bool WhiteMove
        {
            get => whiteMove;
            set
            {
                whiteMove = value;
            }
        }
        public List<Point> CanGo
        {
            get => canGo;
            set
            {
                canGo = value;
            }
        }
        public Figures SelectedFigure
        {
            get => selectedFigure;
            set
            {
                selectedFigure = value;
                OnPropertyChangedvalue();
            }
        }
        public SideChess ChessWhite
        {
            get { return white; }
            set
            {
                white = value;
                OnPropertyChangedvalue();
            }
        }
        public SideChess ChessBlack
        {
            get { return black; }
            set
            {
                black = value;
                OnPropertyChangedvalue();
            }
        }
        
       

        public ViewModal()
        {
            ChessWhite = new SideChess(true);
            ChessBlack = new SideChess(false);
            moveChecks = new ObservableCollection<MoveCheck>();
            chatMessages = new ObservableCollection<ChatMessage>();
            Players = new ObservableCollection<Players>();
        }

        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChangedvalue([CallerMemberName] string property = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(property));
        }
    }
  
}

public class MoveCheck:INotifyPropertyChanged
{
    string figureMove="";
    public string FigureMove { get => figureMove; set { figureMove = value;OnPropertyChangedvalue(); } }
    string nameGoMove="";
    public string NameFoMove { get => nameGoMove; set { nameGoMove = value;OnPropertyChangedvalue(); } }
    string goTo="";
    public string GoTo { get => goTo; set { goTo = value;OnPropertyChangedvalue(); } }
    public event PropertyChangedEventHandler PropertyChanged;
    public void OnPropertyChangedvalue([CallerMemberName] string property = "")
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(property));
    }
}
public class ChatMessage : INotifyPropertyChanged
{
    string name;
    public string Name { get=>name; set {
            name = value;
            OnPropertyChangedvalue();
        } }
    string message;
    public string Message { get=>message; set {
            message = value;
            OnPropertyChangedvalue();
        } }
    public event PropertyChangedEventHandler PropertyChanged;
    public void OnPropertyChangedvalue([CallerMemberName] string property = "")
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(property));
    }
}
public class Players:INotifyPropertyChanged
{
    string name;
    public string Name
    {
        get => name;
        set
        {
            name = value;
            OnPropertyChangedvalue();
        }
    }
    string win_lose;
    public string Win_Lose
    {
        get => win_lose;
        set
        {
            win_lose = value;
            OnPropertyChangedvalue();
        }
    }

    public event PropertyChangedEventHandler PropertyChanged;
    public void OnPropertyChangedvalue([CallerMemberName] string property = "")
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(property));
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.Text.Json;
using System.IO;

namespace Chess
{
    public class WorkToServer
    {
        static int port = 8888;
        public ParsedJsonUser user=new ParsedJsonUser();
        TcpClient client;
        public  NetworkStream stream;
        public enum Commands
        {
            AddUser,
            Test,
            LogIn,
            Update,
            GetAllPlayers,
            GoToGame
        }
        public WorkToServer()
        {
            client = new TcpClient();
        }
        

        public bool Connection()
        {
            try 
            {
                client.Connect(Dns.GetHostName(),port);
                stream = client.GetStream();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public async Task SendPlayerMoveToServer(ParsedPlayerMove move)
        {
            
            await JsonSerializer.SerializeAsync(stream, move);
        }
        public async Task SendToServer(Commands Command)
        {
            user.RequstAndAnswer = Command.ToString();
            await JsonSerializer.SerializeAsync(stream, user);
        }
        public async Task<ParsedJsonUser> GetAnswer()
        {
            return JsonSerializer.Deserialize<ParsedJsonUser>(await ReadNetworkStreamAsync(stream));
        }
        public async Task<ParsedPlayerMove> GetPlayerMove()
        {
            return JsonSerializer.Deserialize<ParsedPlayerMove>(await ReadNetworkStreamAsync(stream));
        }
        public async Task<IEnumerable<UserDb>> GetAnswerForAllPlayers()
        {
            return JsonSerializer.Deserialize<IEnumerable<UserDb>>(await ReadNetworkStreamAsync(stream));
        }
        static async Task<byte[]> ReadNetworkStreamAsync(NetworkStream stream)
        {
            using (MemoryStream ms = new MemoryStream())
            {
                var buffer = new byte[1024];

                int count;
                do
                {
                    count = await stream.ReadAsync(buffer, 0, buffer.Length);
                    await ms.WriteAsync(buffer, 0, count);
                    if (count < 1024)
                    {
                        return ms.ToArray();
                    }
                } while (count > 0);
                return ms.ToArray();
            }
        }
    }
    public class ParsedJsonUser
    {
        public string RequstAndAnswer { get; set; }
        public bool CommandExecuted { get; set; }
        public string Name { get; set; }
        public string Password { get; set; }
        public int WinCount { get; set; }
        public int LoseCount { get; set; }
    }
    public class ParsedPlayerMove
    {
        public int x1 { get; set; }
        public int y1 { get; set; }
        public int x2 { get; set; }
        public int y2 { get; set; }
        public string Descriptioon { get; set; }
        public string Message { get; set; }
    }
}
public class UserDb
{
    public int Id { get; set; }
    public string Name { get; set; }
    public string Password { get; set; }
    public int WinCount { get; set; }
    public int LoseCount { get; set; }
}

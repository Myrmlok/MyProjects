﻿// Exam.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//
#include "Filesystem.h"
#include <iostream>
#include <vector>
#include <functional>
#include <string>
#include <initializer_list>
#include "Gallows.h"
using namespace std;

struct MenuEntry
{
    int id = -1;
    string text;
    function<void()> callback;
};

class Menu
{
    string  m_title;
    vector<MenuEntry> m_items;

public:
    Menu(const string& title, initializer_list<MenuEntry> itemsList)
        :m_items(itemsList)
    {
        m_title.assign(title);
    }

    void exec()
    {
        int choice;
        for (;;) {
            clearScreen();

            cout << m_title << endl;
            cout << string(m_title.length(), '-') << endl;

            for (auto& item : m_items) {
                if (item.id < 1)
                    continue;
                cout << item.id << " - " << item.text << endl;
            }
            cout << "0 - Quit" << endl;
            cout << "Enter your choice: ";
            cin >> choice;
            if (cin.bad()) {
                return;
            }
            // !!! Ошибка если ввели не число, нужно сбрасывать сотояние cin
            if (choice == 0 || cin.bad()) {
                if (cin.bad()) {
                    string dummy;
                    cin >> dummy;
                }
                break;
            }

            for (auto& item : m_items) {
                if (item.id == choice) {
                    if (item.callback) {
                        clearScreen();
                        item.callback();
                    }
                    break;
                }
            }
        }
    }

    static void clearScreen()
    {
        system("cls");
        // string scr(30, '\n');
        // cout << scr;
    };
};
int main()
{
    CreateFile file;
    Create_directory dir;
    string str;
    string str1;
    Menu menu_1("filesystem:", {
        {1,"print_dir", [&] { dir.print_dir(); }}
        ,{2,"mkdir",[&] {
            cin >> str;
            dir.mkdir(str.c_str());
            str.clear();
            std::cout << "Write enter";
            char all;
            cin >> all;
         }}
        ,{3,"mkdir(2)",[&] {
         cin >> str;
         cin >> str1;
         dir.mkdir(str.c_str(), str1.c_str());
         str.clear();
         }}
        ,{4,"dir",[&] {
         dir.dir();
         }}
        ,{5,"dir(2)",[&] {
         cin >> str;
         dir.dir(str.c_str());
         str.clear();
         }}
        ,{6,"rename",[&] {
         cin >> str;
         dir.rename(str.c_str());
         str.clear();
         }}
        ,{7,"copy",[&] {
             cin >> str;
             dir.copy(str.c_str());
             str.clear();
         }}
        ,{8,"mkfile/openfile",[&] {
             cin >> str;
             file.create_file(str.c_str());
             str.clear();
         }}
        ,{9,"rename_file",[&] {
         cin >> str;
         cin >> str1;
         dir.rename_file(str.c_str(), str1.c_str());
         str.clear();
         str1.clear();
         }}
        ,{
            10,"rename",[&] {
                cin >> str;
                dir.rename(str.c_str());
                str.clear();
        }}
        ,{11,"copy_file",[&] {
        cin >> str;
        cin >> str1;
        dir.copy_file(str.c_str(), str.c_str());
        str.clear();
        str1.clear();
        }}
        ,{12,"remove",[&] {
        dir.remove();
        }}
        ,{13,"remove(2)",[&] {
            cin >> str;
            dir.remove(str.c_str());
            str.clear();
        }}
            ,{14,"print_static",[&]{
        dir.print_static();
        std::cout << "Write enter";
        char all;
        cin >> all;
        }}
            ,{15,"print_static(2)",[&] {
        cin >> str;
        dir.print_static(str.c_str());
        str.clear();
        std::cout << "Write enter";
        char all;
        cin >> all;
        }}
            ,{16,"print_static_file",[&] {
            cin >> str;
            dir.size_file(str.c_str());
            str.clear();
            std::cout << "Write enter";
            char all;
            cin >> all;
        }}
            ,{17,"write in file",[&] {
        cin >> str;
        file.write(str.c_str());
        str.clear();
        }}
            ,{18,"print  file",[&] {
        file.print_file();
        std::cout << "Write enter";
        char all;
        cin >> all;
        }}
        });
    menu_1.exec();
    
    Gallows gal;
    gal.start();
    
}

// Запуск программы: CTRL+F5 или меню "Отладка" > "Запуск без отладки"
// Отладка программы: F5 или меню "Отладка" > "Запустить отладку"

// Советы по началу работы 
//   1. В окне обозревателя решений можно добавлять файлы и управлять ими.
//   2. В окне Team Explorer можно подключиться к системе управления версиями.
//   3. В окне "Выходные данные" можно просматривать выходные данные сборки и другие сообщения.
//   4. В окне "Список ошибок" можно просматривать ошибки.
//   5. Последовательно выберите пункты меню "Проект" > "Добавить новый элемент", чтобы создать файлы кода, или "Проект" > "Добавить существующий элемент", чтобы добавить в проект существующие файлы кода.
//   6. Чтобы снова открыть этот проект позже, выберите пункты меню "Файл" > "Открыть" > "Проект" и выберите SLN-файл.

#include "Filesystem.h"

void Create_directory::mkdir(const char* name_new_directory)
{
	fs::create_directories(m_path / name_new_directory);
	m_path = (m_path / name_new_directory);
}

void Create_directory::mkdir(const char* name_path, const char* name_new_directory)
{
	fs::path new_path(name_path);
	if (!fs::exists(new_path)) {
		return;
	}
	fs::create_directories(new_path / name_new_directory);
}

void Create_directory::dir(const char* name_directory)
{
	if (!fs::exists(fs::current_path() / name_directory)) {
		std::cout << "Not souch directory" << std::endl;
		return;
	}
	m_path = (fs::current_path() / name_directory);
}

void Create_directory::dir()
{
	if (fs::current_path() == m_path) {
		return;
	}
	m_path = m_path.parent_path();
}

void Create_directory::rename(const char* new_name)
{
	if (m_path == fs::current_path()) {
		return;
	}
	fs::rename(m_path, new_name);
}

void Create_directory::rename_file(const char* old_name, const char* new_name)
{
	if (!fs::exists(m_path / old_name)) {
		return;
	}
	fs::rename(m_path / old_name, new_name);
}

void Create_directory::rename(const char* name_directory, const char* new_name)
{
	if (!fs::exists(fs::current_path() / name_directory)) {
		return;
	}
	fs::rename(name_directory, new_name);
}

void Create_directory::copy(const char* new_directory)
{
	if (!fs::exists( new_directory)) {
		return;
	}
	fs::copy(m_path, new_directory);
}

void Create_directory::copy(const char* old_directory, const char* new_directory)
{
	if (!fs::exists(fs::current_path()/old_directory) ||
		!fs::exists(fs::current_path()/ new_directory)) {
		return;
	}
	fs::copy(old_directory, new_directory);
}

void Create_directory::copy_file(const char* filename, const char* new_directory)
{
	if (!fs::exists(fs::current_path() / new_directory)) {
		return;
	}
	fs::copy(filename, fs::current_path()/ new_directory);
}

void Create_directory::print_static()
{
	size_t size = 0;
	for (auto& dir_entry : fs::recursive_directory_iterator(m_path)) {
		size += fs::file_size(dir_entry);
	}
	std::cout << "Size dir:" << size << std::endl;
}

void Create_directory::print_static(const char* directory)
{
	if (!fs::exists(fs::current_path() / directory)) {
		return;
	}
	size_t size = 0;
	for (auto& dir_entry : fs::recursive_directory_iterator(directory)) {
		if (dir_entry.is_block_file()) {
			size += fs::file_size(dir_entry.path());
		}
	}
	std::cout << "Size dir:" << size << std::endl;
}

void Create_directory::size_file(const char* filename)
{
	if (!fs::exists(fs::current_path() / filename) && !fs::exists(m_path / filename)) {
		return;
	}
	std::cout << "File size:" << fs::file_size(filename) << std::endl;
};

void Create_directory::remove()
{
	if (m_path == fs::current_path()) {
		return;
	}
	fs::remove_all(m_path);
}

void Create_directory::remove(const char* name_path)
{
	fs::path new_path(fs::current_path() / name_path);
	if (!fs::exists(new_path)) {
		return;
	}

	if (fs::is_directory(new_path)) {
		remove_all(new_path);
		return;
	}
	fs::remove(new_path);
}



void Create_directory::print_dir()
{
	std::cout << m_path << std::endl;
}



void Create_directory::print(const char* name_path)
{
	fs::path new_path = name_path;
	if (!fs::exists(new_path)) {
		return;
	}
	for (auto& dir_entry : fs::recursive_directory_iterator(new_path)) {
		std::cout << dir_entry.path() << std::endl;
	}
}



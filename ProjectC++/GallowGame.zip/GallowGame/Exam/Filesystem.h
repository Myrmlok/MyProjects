#pragma once
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <filesystem>
#include <fstream>
#include <string>
#include <cstdio>

namespace fs = std::filesystem;
class Create_directory {
	fs::path m_path=fs::current_path();
public:
	Create_directory(){}
	~Create_directory(){}
	void mkdir(const char* name_new_directory);
	void mkdir(const char* name_path, const char* name_new_directory);
	void dir(const char* name_directory);
	void dir();
	void rename(const char* new_name);
	void rename_file(const char* old_name, const char* new_name);
	void rename(const char* name_directory, const char* new_name);
	void copy(const char* new_directory);
	void copy(const char* old_directory, const char* new_directory);
	void copy_file(const char* filename, const char* new_directory);
	void print_static();
	void print_static(const char* directory);
	void size_file(const char* filename);
	void remove();
	void remove(const char* name_path);
	void print_dir();
	void print(const char* name_path);
	fs::path getPath() { return m_path; }
};
class CreateFile {
	std::string m_filename;
	
public:
	CreateFile() {}
	CreateFile(const char* filename){
		m_filename.assign(filename);
		std::ofstream(m_filename.c_str());
	}
	~CreateFile() {
	}
	void create_file(const char* filename) {
		m_filename.assign(filename);
		std::ofstream(m_filename.c_str());
	}
	void copy(const char* _path) {
		if (fs::exists(_path)) {
			return;
		}
		fs::copy(m_filename, _path);
	}
	void write(const char* _text) {
		
		FILE* fp=std::fopen(m_filename.c_str(), "w");
		std::fwrite(_text, std::strlen(_text), sizeof(char), fp);
		std::fclose(fp);
	}
	void print_file() {
		
		FILE* fp = std::fopen(m_filename.c_str(), "r");
		std::string buf;
		buf.resize(fs::file_size(m_filename));
		std::fread(&buf[0], fs::file_size(m_filename), sizeof(char), fp);
		std::cout << buf;
		std::fclose(fp);
	}
	void file_clear() {
		std::fstream(m_filename, std::fstream::out);
	}
	std::string filename() {
		return m_filename;
	}
};

#include "Gallows.h"
const char* Gallows::password = "dimabest";

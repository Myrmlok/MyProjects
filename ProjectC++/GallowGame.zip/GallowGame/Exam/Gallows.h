#pragma once
#include "Filesystem.h"
#include <iomanip>
#include <vector>
#include <random>
#include <chrono>
class Chiper {
	std::vector<uint8_t> m_password;

public:
	Chiper(const std::vector<uint8_t>& password) :m_password(password) {}
	Chiper(const std::string& password) :m_password(password.begin(), password.end()) {}
	void encrypt(std::vector<uint8_t>& data)
	{
		for (auto it = data.begin(); it != data.end(); ++it) {
			auto j = std::distance(data.begin(), it) % m_password.size();
			*it ^= m_password.at(j);
		}
	}
	void encrypt(std::string& str) {
		std::vector<uint8_t> data(str.begin(), str.end());
		for (auto it = data.begin(); it != data.end(); ++it) {
			auto j = std::distance(data.begin(), it) % m_password.size();
			*it ^= m_password.at(j);
		}
		str.assign(data.begin(), data.end());
	}
	void decrypt(std::vector<uint8_t>& data) { encrypt(data); }
};

class Gallows
{
	size_t m_size;
	std::string filename{};
	std::string word{};
	static const char* password;
public:
	~Gallows() {
		filename.clear();
		word.clear();
		m_size = 0;
	}
	Gallows() {
		if (fs::exists("Gallow.txt")) {
			if(fs::file_size("Gallow.txt")==0){}
			else {
				m_size = fs::file_size("Gallow.txt");
				filename.assign("Gallow.txt");
			}
		}
		CreateFile fp("Gallow.txt");
		Chiper chiper(password);
		std::string wor("animal0cat0dog0parrot0elephant0tiger0cow0hamster0horse0pig0");
		
		std::vector<uint8_t> words;
		words.assign(wor.begin(), wor.end());
		chiper.encrypt(words);
		FILE* f = fopen("Gallow.txt", "w");
		std::fwrite(&words[0], words.size(), sizeof(words[0]), f);
		
		filename.assign("Gallow.txt");
		fclose(f);
		m_size = wor.size();
	}
	void start() {
		FILE* fp = fopen(filename.c_str(), "r");
		Chiper chiper(password);
		std::vector<uint8_t> buf;
		buf.resize(m_size);
		std::fread(&buf[0], fs::file_size(filename.c_str()), sizeof(buf[0]), fp);
		chiper.encrypt(buf);
		
		
		std::fclose(fp);
		{
			std::random_device r;
			std::default_random_engine e1(r());
			std::uniform_int_distribution<int> uniform_dist(0, 9);
			int rand = uniform_dist(e1);
			bool choize=false;
			for (size_t i = 0; !choize;i++) {
				if (buf[i]=='0') {
					rand--;
				}
				if (rand == 0) {
		
					for (size_t j = i + 1; ; j++) {
						if (buf[j] == '0') {
							break;
						}
						
						word.push_back(buf[j]) ;
						
					}
					choize = true;
				}
			}
			
		}
		buf.clear();
		bool isDone = false;
		char ch='0';
		std::string true_attempt;
		true_attempt.resize(word.size(),'_');
		int attempt= word.size() *2;
		auto start=std::chrono::steady_clock::now();
		while (!isDone) {
			std::cout << "attempt:" << attempt << std::endl;
			std::cout << true_attempt << std::endl;
			std::cout << "Write char:";
			std::cin >> ch;
			if (std::cin.bad()) {
				std::cin.clear();
			}
			bool _double=false;
			for (size_t i = 0; i < word.size(); i++) {
				if (word[i] == ch) {
					true_attempt[i] = ch;
					_double = true;
				}
				if (i == word.size()-1&& !_double) {
					attempt--;
				}
			}
			if (attempt == 0) {
				std::cout << "You lose" << std::endl;
				isDone = true;
			}
			for (size_t i = 0; i < word.size(); i++) {
				if (true_attempt[i] != word[i]) {
					break;
				}
				if (i == word.size()-1) {
					std::cout << "You win" << std::endl;
					isDone = true;
				}
			}
		}
		auto final= std::chrono::steady_clock::now();
		std::cout <<"Time:"<< std::chrono::duration_cast<std::chrono::minutes>(final - start).count()<<":"
			<< std::chrono::duration_cast<std::chrono::seconds>(final - start).count() % std::chrono::minutes::period::num << std::endl;
		std::cout << "This word is:" << word;
		word.clear();
	}
};

